package com.prashanth.tapi;

import java.awt.Dimension;
import java.awt.Toolkit;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import com.prashanth.ui.TapiWindow;
import com.prashanth.utils.Http;

/**
 * 
 * @author 658762
 *
 *
 */
public class App {
	public static void main(String[] args) {
		
//		TapiWindow tw = new TapiWindow("Welcome");
//		tw.setVisible(true);
//		
//		
//		System.out.println("Hello World!");
//		JPanel jp = new JPanel();
//		JFrame jf = new JFrame();
//		
//		// fetch current screen dimensions
//		Dimension dm = Toolkit.getDefaultToolkit().getScreenSize();
//		//jf.setSize( (int) dm.getWidth()/2, (int) dm.getHeight()/2);
//		jf.setSize( (int) dm.getWidth()-200, (int) dm.getHeight()-200);
//		
//		
//		
//		JTextField jTextField = new JTextField(50);
//		JButton jb = new JButton("Go");
//		jp.add(jTextField);
//		jp.add(jb);
//		
//		
//		JRadioButton jrGet = new JRadioButton("GET");
//		JRadioButton jrPost = new JRadioButton("POST");
//		jp.add(jrGet);
//		jp.add(jrPost);
		
//		jf.add(jp);
//		jf.setVisible(true);
//		
	

//		
		try {

			System.setProperty("http.proxySet", "true");
			System.setProperty("http.proxyHost","proxy.cognizant.com");
			System.setProperty("http.proxyPort","6050");
			
			Http http = new Http();
			String output = http.get("https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&symbol=MSFT&apikey=demo");
			System.out.println("request sent");
			System.out.println(output);
			System.out.println("output");
			
		} catch (Exception ex) { 
			// TODO : should log proper exception
			System.out.println("exception : "+ex);
		}
		
	}
}
