package com.prashanth.utils;
/**
 * 
 * @author 658762
 *
 */
public class Constants {

	static final String GET = "GET";
	static final String POST = "POST";
	
}
