package com.prashanth.utils;

public class Utility {

	/**
	 * @param s
	 *            : input string to check
	 * @return empty string
	 */
	public static String empty(String s) {
		return "";
	}

	/**
	 * this method is used to check if
	 * @param s
	 *            : is empty or not
	 * @return boolean value
	 */
	public static boolean isEmpty(String s) {
		boolean result = false;
		if (s == "" || s == null) {
			result = true;
		}
		return result;
	}

	public static Object setNull() {
		return null;
	}
}
