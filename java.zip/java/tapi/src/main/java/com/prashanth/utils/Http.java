package com.prashanth.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;
	
/***
 * Created by @author Prashanth Dasari on 02-12-2017.
 *
 * all copyrights are reserved. 
 * Custom designed class, which provides get & post requests.
 *
 ***/

public class Http {

	
	private static URL urlObject = (URL) Utility.setNull();
	private static HttpsURLConnection httpsURLConnection = (HttpsURLConnection) Utility.setNull();
	private static BufferedReader bufferedReader = (BufferedReader) Utility.setNull();
	private static OutputStream outputStreams = (OutputStream) Utility.setNull();
	private static String responseData = (String) Utility.setEmpty();

	
	public static String get(String url) {
		String output;
		// String responseData = (String) Utility.setNull();
		try {
			urlObject = new URL(url);
			httpsURLConnection = (HttpsURLConnection) urlObject.openConnection();
			httpsURLConnection.setRequestMethod(Constants.GET);
			httpsURLConnection.setRequestProperty("Content-Type", "application/json");

			setOutput();

			// Opening stream and reading output
			bufferedReader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
			while ((output = bufferedReader.readLine()) != null) {
				// appending every line to a string
				responseData = responseData + output;
			}
		} catch (Exception exception) {
			// Todo : error handling
			System.out.println("Exception in Http.get : "+ exception);
		} finally {
			httpsURLConnection.disconnect();
		}
		return responseData;
	}

	public static String post(String bodyRequest) {
		String output;
		// String responseData = (String) Utility.setNull();
		try {
			httpsURLConnection = (HttpsURLConnection) urlObject.openConnection();
			httpsURLConnection.setRequestMethod(Constants.POST);
			httpsURLConnection.setRequestProperty("Content-Type", "application/json");
			setOutput();
			setInput();

			// writing post request's json body
			outputStreams = httpsURLConnection.getOutputStream();
			outputStreams.write(bodyRequest.getBytes());
			outputStreams.flush();

			// Opening stream and reading output
			bufferedReader = new BufferedReader(new InputStreamReader(httpsURLConnection.getInputStream()));
			while ((output = bufferedReader.readLine()) != null) {
				// appending every line to a string
				responseData = responseData + output;
			}
			/*if (httpsURLConnection.getResponseCode() == HttpURLConnection.HTTP_ACCEPTED)
				//Log.i(TAG, "post: request successful : " + httpsURLConnection.getResponseCode());
			else
				//Log.i(TAG, "post: request unsuccessful : " + httpsURLConnection.getResponseCode());
		
			 */
		} catch (Exception exception) {
			//Log.i(TAG, "post Method: exception occurred : " + exception.getMessage());
		} finally {
			httpsURLConnection.disconnect();
		}
		return responseData;
	}

	private static void setOutput() {
		httpsURLConnection.setDoOutput(true);
	}

	private static void setInput() {
		httpsURLConnection.setDoInput(true);
	}
}