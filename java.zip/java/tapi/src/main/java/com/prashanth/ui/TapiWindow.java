package com.prashanth.ui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JTextField;

public class TapiWindow extends JFrame {
	
	private double width;
	private double height;
	
	private JLabel label;
	
	public TapiWindow(String windowTitle){

		// calling parent constructor
		super (windowTitle);
		
		// setting layout to flow
		setLayout(new FlowLayout());
		
		// fetching current system screen size
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		width = dim.getWidth();
		height = dim.getHeight();
		setSize((int)width, (int)height);
		
		// default close option enabled
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		label = new JLabel("Custom Frame window");
		
		// adding label component to window
		add (label);
		
		
		//working on JMenuBar and JMenu items
		JMenuBar jmb = new JMenuBar();
		JMenu jm = new JMenu("Options");
		JMenuItem jmiSettings = new JMenuItem("Settings");
		JMenuItem jmiAbout = new JMenuItem("About");
		//JMenuItem jmiHelp = new JMenuItem("Help");
		JMenuItem jmiExit = new JMenuItem("Exit");
		
		// request & response text field components
		JTextField requestText = new JTextField(100);
		JTextField responseText = new JTextField(100);
		
		// setting proper sizes to text fields
		//requestText.setSize(getWidth()/2 - 1, getHeight()/2 - 1);
		//requestText.setBounds(10, 10, this.getWidth()/2 - 5, this.getHeight()/2 - 5);
		//responseText.setBounds(getWidth()/2, getHeight()/2, getWidth(), getHeight());
		//requestText.setSize(getWidth()/2 - 1, getHeight()/2 - 1);

		// action to exitMenuItem under options menu
		jmiExit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				System.exit(0);
			}
		});
		
		
		add( requestText );
		add( responseText );
		
		jm.add(jmiSettings);
		jm.add(jmiAbout);
		jm.add(jmiExit);
		
		jmb.add(jm);
		
		setJMenuBar(jmb);
		
	}
	
	
}
