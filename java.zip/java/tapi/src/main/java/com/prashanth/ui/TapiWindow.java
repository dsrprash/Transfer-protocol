package com.prashanth.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class TapiWindow extends JFrame {
	
	private double width;
	private double height;
	
	
	public TapiWindow(String windowTitle){
		
		// calling parent constructor
		super (windowTitle);
		
		Box titleText = Box.createHorizontalBox();
		JLabel title = new JLabel("<html><span style='color: teal;'>Tapi</span><br/></html>");
		title.setFont (title.getFont().deriveFont(64.0f));
		

		
		
		// setting layout to flow
		setLayout(new FlowLayout());
		
		// fetching current system screen size
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		width = dim.getWidth();
		height = dim.getHeight();
		setSize((int)width, (int)height);
		
		// default close option enabled
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// adding label component to window
		add (title);
		
		
		//working on JMenuBar and JMenu items
		JMenuBar jmb = new JMenuBar();
		JMenu jm = new JMenu("Options");
		JMenuItem jmiSettings = new JMenuItem("Settings");
		JMenuItem jmiAbout = new JMenuItem("About");
		//JMenuItem jmiHelp = new JMenuItem("Help");
		JMenuItem jmiExit = new JMenuItem("Exit");
		
		// request & response text field components
		JTextArea requestText = new JTextArea("please give body request here!");
		JTextArea responseText = new JTextArea("request response will be here!");
		
		// default size preference
		requestText.setLineWrap(true);
		responseText.setLineWrap(true);
	    requestText.setMinimumSize(new Dimension(150, 150));
	    responseText.setMinimumSize(new Dimension(150, 150));
	    requestText.setPreferredSize(new Dimension(250, 200));
		
		// JSplitPane divides two components with equal or adjustable
		// according to the screen size
		JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, requestText, responseText);
		
		// setting proper sizes to text fields
		//requestText.setSize(getWidth()/2 - 1, getHeight()/2 - 1);
		//requestText.setBounds(10, 10, this.getWidth()/2 - 5, this.getHeight()/2 - 5);
		//responseText.setBounds(getWidth()/2, getHeight()/2, getWidth(), getHeight());
		//requestText.setSize(getWidth()/2 - 1, getHeight()/2 - 1);

		// action to exitMenuItem under options menu
		jmiExit.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent ae){
				System.exit(0);
			}
		});
		
		
		// adding splitpane to the frame
		getContentPane().add(splitPane);
		
		// for time being, don't add since splitpane concept is working
		/*
		add( requestText );
		add( responseText );
		*/
		
		
		jm.add(jmiSettings);
		jm.add(jmiAbout);
		jm.add(jmiExit);
		
		jmb.add(jm);
		
		setJMenuBar(jmb);
		
	}
	
	
}
