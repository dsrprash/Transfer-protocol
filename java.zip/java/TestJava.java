class TestJava{
public static void main(String a[]){
System.out.println("java is working!!");
}
}